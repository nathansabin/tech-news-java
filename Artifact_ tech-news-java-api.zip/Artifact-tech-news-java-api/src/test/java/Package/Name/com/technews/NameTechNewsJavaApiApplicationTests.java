package Package.Name.com.technews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NameTechNewsJavaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
