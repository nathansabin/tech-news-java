package Package.Name.com.technews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NameTechNewsJavaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NameTechNewsJavaApiApplication.class, args);
	}

}
